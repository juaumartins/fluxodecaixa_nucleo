#!/usr/bin/env python3
"""
Servidor Local - Fluxo de Caixa Núcleo Jardim Florido
Executa um servidor HTTP local simples e abre o navegador automaticamente.
"""

import http.server
import socketserver
import webbrowser
import os

PORT = 8000
DIRECTORY = os.path.dirname(os.path.abspath(__file__))

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

def main():
    os.chdir(DIRECTORY)
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        url = f"http://localhost:{PORT}"
        print("=" * 60)
        print("🌿 FLUXO DE CAIXA - NÚCLEO JARDIM FLORIDO")
        print(f"Servidor iniciado em: {url}")
        print("Pressione CTRL + C para encerrar.")
        print("=" * 60)
        
        try:
            webbrowser.open(url)
        except Exception:
            pass
            
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nServidor encerrado com sucesso.")

if __name__ == "__main__":
    main()
